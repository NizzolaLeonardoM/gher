# gher.github.io
Nota: Il saldo del gioco è finto e non vuole rappresentare una valuta reale. 
Questo gioco e' un progetto didattico nato per gioco; non vuole in alcun modo incitare il gioco d'azzardo.
